const endpoints = {
    getStates: "/v0.1/countries/states/",
    getCities: "/v0.1/countries/state/cities/",
    getPosts: "/v0.1/countries/states/q"  /* creatung endpoint*/
  };
  
  export default endpoints;